# Java OOP Project

Proyek ini berisi tiga bagian:
1. Soal Generic class `Mahasiswa`
2. Contoh penggunaan `ArrayList` dan `ArrayDeque`
3. Mini project Java OOP dengan:
   - Class & Object
   - Inheritance & Polymorphism
   - Encapsulation
   - Interface & Abstract
   - Generic & Collection
