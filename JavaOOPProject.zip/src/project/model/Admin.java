package project.model;

public class Admin extends User {
    public Admin(String username, String email) {
        super(username, email);
    }

    @Override
    public void showRole() {
        System.out.println("Role: Admin");
    }
}
